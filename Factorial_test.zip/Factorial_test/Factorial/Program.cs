﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FactorialP;
internal class Program
{
    private static void Main(string[] args)
    {
        var f = new FactorialClass();
        Console.WriteLine(f.factorial(f.a));
    }
}